﻿MSBT Quick Menu — AzzaRock test pack
====================================
Build: latest Quick Menu wrap-in (spawnables + remaining commands)
Branch: cursor/quick-menu-native-umg-0b18

Contents
--------
1) MattsSDKBoostingTools.sdkmod
2) Electron-Patch\resources\app.asar  (Quick Menu editor + + QM buttons)
3) INSTALL_FOR_TESTERS.txt
4) QUICK_MENU_PREVIEW_NOTES.txt

Quick start
-----------
1. Close Borderlands 4 and MSBT.
2. Backup then replace your sdk_mods\MattsSDKBoostingTools.sdkmod with the one in this zip.
3. Patch MSBT 1.2.0: backup resources\app.asar, then copy Electron-Patch\resources\app.asar over it.
4. Launch game -> load into world -> F7 for Quick Menu.
5. In MSBT open the Quick Menu tab; use + QM on Item Pool / Travel / Serial / etc.

Controls: F7 open/close, F6 unstuck, Escape closes modals then menu.

No BLImGui required. Loot-pool tooling beyond item-pool spawn pins is separate.

Please report: F7 DPI/size, Target modal, Pin Last from MSBT actions, + QM spawn/travel/serial, crashes.
