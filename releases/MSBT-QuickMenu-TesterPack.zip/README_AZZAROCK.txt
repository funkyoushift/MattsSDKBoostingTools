﻿MSBT Quick Menu — AzzaRock test pack
====================================
Includes Pin Last / Repeat Last Drop / Lock Player controls in the Electron ★ Quick Menu tab.

1) Close game + MSBT
2) Replace sdk_mods\MattsSDKBoostingTools.sdkmod
3) Patch MSBT resources\app.asar from Electron-Patch\
4) Launch game into world, open MSBT, click ★ Quick Menu
