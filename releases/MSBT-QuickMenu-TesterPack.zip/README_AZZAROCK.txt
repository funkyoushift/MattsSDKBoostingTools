Right-side dock UI + BL4/Bookmark +QM
